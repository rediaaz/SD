﻿using PokemonWebServer.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace PokemonWebServer.Controllers {

    [RoutePrefix("api/pokemon")]
    public class PokemonController : ApiController {

        private static List<PokemonModel> listaPokemon = new List<PokemonModel>();

        [AcceptVerbs("POST")]
        [Route("CadastrarPokemon")]
        public string Post(PokemonModel pokemon) {
            
            if(listaPokemon.Count() == 0) {
                pokemon.Id = 1;
            } else {
                pokemon.Id = listaPokemon[listaPokemon.Count() - 1].Id + 1;
            }
            

            listaPokemon.Add(pokemon);
            return "Pokemon cadastrado com sucesso";
        }

        [AcceptVerbs("PUT")]
        [Route("AlterarPokemon")]
        public string Put(PokemonModel pokemon) {
            listaPokemon.Where(n => n.Id == pokemon.Id).
                        Select(s => {
                            s.Id = pokemon.Id;
                            s.Nome = pokemon.Nome;
                            s.Poder = pokemon.Poder;

                            return s;
                        }).ToList();
            return "Pokemon alterado com sucesso";
        }


        [AcceptVerbs("DELETE")]
        [Route("ExcluirPokemon/{id}")]
        public string Delete(int id) {
            PokemonModel pokemon = listaPokemon.Where(n => n.Id == id)
                                               .Select(n => n)
                                               .First();
            listaPokemon.Remove(pokemon);

            return "Pokemon removido com sucesso";
        }


        [AcceptVerbs("GET")]
        [Route("ConsultarPokemons/{id}")]
        public PokemonModel GetById(int id) {
            PokemonModel pokemon = listaPokemon.Where(n => n.Id == id)
                                                .Select(n => n)
                                                .First();

            return pokemon;
        }

        [AcceptVerbs("GET")]
        [Route("ConsultarPokemons")]
        public List<PokemonModel> Get() {
            return listaPokemon;
        }
        
    }
}
