﻿namespace PokemonAPP.Models
{
    public class PokemonModel
    {
        public PokemonModel(string nome, string poder) {
            Nome = nome;
            Poder = poder;
        }

        public PokemonModel() {

        }

        public PokemonModel(int id, string nome, string poder) {
            Id = id;
            Nome = nome;
            Poder = poder;
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Poder { get; set; }
    }
}
