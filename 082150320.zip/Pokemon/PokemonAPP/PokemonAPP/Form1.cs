﻿using Newtonsoft.Json;
using PokemonAPP.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PokemonAPP
{
    public partial class Pokemon : Form
    {
        public Pokemon()
        {
            InitializeComponent();
        }

        private void Pokemon_Load(object sender, EventArgs e) {
            var dados = new List<PokemonModel>();

            using (var client = new HttpClient()) {

                client.BaseAddress = new Uri("http://localhost:52730/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.GetAsync("api/pokemon/ConsultarPokemons").Result;
                if (response.IsSuccessStatusCode) {
                    var product = response.Content.ReadAsStringAsync();
                    dados = JsonConvert.DeserializeObject<List<PokemonModel>>(product.Result);
                } else {

                }

                var list = new BindingList<PokemonModel>(dados);
                dgvDados.DataSource = list;
            }
        }

        private void btnInserir_Click(object sender, EventArgs e) {
            try {
                PokemonModel pokemon = new PokemonModel(
                    21,
                    txtNome.Text,
                    txtPoder.Text
                );

                using (var client = new HttpClient()) {

                    Task<HttpResponseMessage> response = client.PostAsJsonAsync("http://localhost:52730/api/pokemon/CadastrarPokemon", pokemon);

                    MessageBox.Show("Novo pokemon incluído com sucesso.");
                    txtNome.Clear();
                    txtPoder.Clear();
                    txtNome.Focus();
                    exibirDados();
                }

            } catch (Exception ex) {
                MessageBox.Show("Erro : " + ex.Message, "Pokemons", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void exibirDados() {
            var dados = new List<PokemonModel>();

            using (var client = new HttpClient()) {

                client.BaseAddress = new Uri("http://localhost:52730/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.GetAsync("api/pokemon/ConsultarPokemons").Result;
                if (response.IsSuccessStatusCode) {
                    var product = response.Content.ReadAsStringAsync();
                    dados = JsonConvert.DeserializeObject<List<PokemonModel>>(product.Result);
                } else {

                }

                var list = new BindingList<PokemonModel>(dados);
                dgvDados.DataSource = list;
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e) {
            
            int Id = 0;

            if (dgvDados.SelectedRows.Count > 0) {
                Id = Convert.ToInt32(dgvDados.SelectedRows[0].Cells["Id"].Value.ToString());
            }

            if (txtNome.Text.Equals("") || txtPoder.Text.Equals("")) {
                MessageBox.Show("Os dados necessários não foram informados.", "Atualizar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try {
                PokemonModel pokemon = new PokemonModel(
                    Id,
                    txtNome.Text,
                    txtPoder.Text
                );

                using (var client = new HttpClient()) {

                    Task<HttpResponseMessage> response = client.PutAsJsonAsync("http://localhost:52730/api/pokemon/AlterarPokemon", pokemon);

                    MessageBox.Show("Novo pokemon atualizado com sucesso.");
                    txtNome.Clear();
                    txtPoder.Clear();
                    txtNome.Focus();
                    exibirDados();
                }

            } catch (Exception ex) {
                MessageBox.Show("Erro : " + ex.Message, "Pokemon", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnDeletar_Click(object sender, EventArgs e) {
            try {
                DialogResult dr = MessageBox.Show("Deseja excluir este pokemon ?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (dr == DialogResult.Yes) {

                    foreach (DataGridViewRow item in this.dgvDados.SelectedRows) {

                        var Id = item.Cells[0].Value;

                        using (var client = new HttpClient()) {

                            Task<HttpResponseMessage> response = client.DeleteAsync("http://localhost:52730/api/pokemon/ExcluirPokemon/" + Id);
                            MessageBox.Show("Pokemon excluído com sucesso.");
                            txtNome.Clear();
                            txtPoder.Clear();
                            txtNome.Focus();
                            exibirDados();
                        }
                    }
                }
            } catch {
                throw;
            }
        }

        private void btnSair_Click(object sender, EventArgs e) {
            DialogResult dr = MessageBox.Show("Deseja encerrar a aplicação ?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            if (dr == DialogResult.Yes)
                Application.Exit();
        }

        private void dgvDados_CellClick(object sender, DataGridViewCellEventArgs e) {
            //verifica se o indice da linha da celeula é maior ou igual a zero
            if (e.RowIndex >= 0) {
                //pega a coleção que contém todas as linhas
                DataGridViewRow row = this.dgvDados.Rows[e.RowIndex];
                //preenche os textbox com os valores
                txtNome.Text = row.Cells[1].Value.ToString();
                txtPoder.Text = row.Cells[2].Value.ToString();
            }
        }

        private void dgvDados_CellContentClick(object sender, DataGridViewCellEventArgs e) {
            //verifica se o indice da linha da celeula é maior ou igual a zero
            if (e.RowIndex >= 0) {
                //pega a coleção que contém todas as linhas
                DataGridViewRow row = this.dgvDados.Rows[e.RowIndex];
                //preenche os textbox com os valores
                txtNome.Text = row.Cells[1].Value.ToString();
                txtPoder.Text = row.Cells[2].Value.ToString();
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e) {
            var dados = new List<PokemonModel>();
            PokemonModel pokemon = new PokemonModel();

            if (txtProcurar.Text == "") {
                exibirDados();
            } else {
                int codigo = Convert.ToInt32(txtProcurar.Text);

                using (var client = new HttpClient()) {

                    client.BaseAddress = new Uri("http://localhost:52730/");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    HttpResponseMessage response = client.GetAsync("http://localhost:52730/api/pokemon/ConsultarPokemons/" + codigo).Result;

                    if (response.IsSuccessStatusCode) {
                        var pokemonResult = response.Content.ReadAsStringAsync();
                        pokemon = JsonConvert.DeserializeObject<PokemonModel>(pokemonResult.Result);
                    } else {

                    }
                    dados.Add(pokemon);
                    var list = new BindingList<PokemonModel>(dados);
                    dgvDados.DataSource = list;
                }
            }
        }

        private void btnMostrarTudo_Click(object sender, EventArgs e) {
            var dados = new List<PokemonModel>();

            using (var client = new HttpClient()) {

                client.BaseAddress = new Uri("http://localhost:52730/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.GetAsync("api/pokemon/ConsultarPokemons").Result;
                if (response.IsSuccessStatusCode) {
                    var product = response.Content.ReadAsStringAsync();
                    dados = JsonConvert.DeserializeObject<List<PokemonModel>>(product.Result);
                } else {

                }

                var list = new BindingList<PokemonModel>(dados);
                dgvDados.DataSource = list;
            }
        }
    }
}
